<?php
/**
 * ULTRA FAST VIDEO DOWNLOADER - COMPACT EDITION
 * Updated to use davidcyriltech.my.id APIs
 */

ob_start();

$stats_file = 'stats.json';
if (!file_exists($stats_file)) {
    file_put_contents($stats_file, json_encode(['total_users' => 0, 'total_downloads' => 0]));
}

$stats = json_decode(file_get_contents($stats_file), true);

session_start();
if (!isset($_SESSION['visited'])) {
    $_SESSION['visited'] = true;
    $stats['total_users']++;
    file_put_contents($stats_file, json_encode($stats));
}

function fetch_api($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) return null;
    return json_decode($response, true);
}

$search_results = [];
$download_link = null;
$video_details = null;
$error = null;
$query = isset($_POST['query']) ? trim($_POST['query']) : '';
$action = isset($_POST['action']) ? $_POST['action'] : '';
$video_id = isset($_POST['video_id']) ? $_POST['video_id'] : '';
$video_title = isset($_POST['video_title']) ? $_POST['video_title'] : '';
$video_thumbnail = isset($_POST['video_thumbnail']) ? $_POST['video_thumbnail'] : '';
$video_duration = isset($_POST['video_duration']) ? $_POST['video_duration'] : '';
$video_views = isset($_POST['video_views']) ? $_POST['video_views'] : '';
$video_author = isset($_POST['video_author']) ? $_POST['video_author'] : '';
$video_uploaded = isset($_POST['video_uploaded']) ? $_POST['video_uploaded'] : '';
$show_details = isset($_POST['show_details']) ? $_POST['show_details'] : false;

function format_views($views) {
    if (empty($views)) return '0';
    if (!is_numeric($views)) return $views;
    if ($views >= 1000000) return round($views / 1000000, 1) . 'M';
    if ($views >= 1000) return round($views / 1000, 1) . 'K';
    return $views;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'search' && !empty($query)) {
        $search_url = "https://apis.davidcyriltech.my.id/youtube/search?query=" . urlencode($query);
        $data = fetch_api($search_url);
        if ($data && isset($data['status']) && $data['status'] && isset($data['results']) && is_array($data['results'])) {
            $search_results = array_slice($data['results'], 0, 12);
        } else {
            $error = "No videos found.";
        }
    } elseif ($action === 'view_details' && !empty($video_id)) {
        $show_details = true;
        $video_details = ['id' => $video_id, 'title' => $video_title, 'thumbnail' => $video_thumbnail, 'duration' => $video_duration, 'views' => $video_views, 'author' => $video_author, 'uploaded' => $video_uploaded];
    } elseif ($action === 'download' && !empty($video_id)) {
        $show_details = true;
        $video_details = ['id' => $video_id, 'title' => $video_title, 'thumbnail' => $video_thumbnail, 'duration' => $video_duration, 'views' => $video_views, 'author' => $video_author, 'uploaded' => $video_uploaded];
        $youtube_url = "https://www.youtube.com/watch?v=" . $video_id;
        $formats = ['360', '720', 'mp3', '480'];
        foreach ($formats as $format) {
            $api_url = "https://apis.davidcyriltech.my.id/download/savetube?url=" . urlencode($youtube_url) . "&format=" . $format;
            $data = fetch_api($api_url);
            if ($data && isset($data['success']) && $data['success'] && isset($data['data']['download_url'])) {
                $download_link = $data['data']['download_url'];
                break;
            }
        }
        if ($download_link) {
            $stats['total_downloads']++;
            file_put_contents($stats_file, json_encode($stats));
        } else {
            $error = "Failed to generate link.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ultra Downloader</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f9fafb; }
        .compact-card { transition: all 0.2s; }
        .compact-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    </style>
</head>
<body class="min-h-screen flex flex-col items-center p-4" x-data="{ loading: false }">

    <div class="w-full max-w-2xl">
        <!-- HEADER -->
        <header class="flex items-center justify-between mb-6">
            <a href="index.php" class="flex items-center gap-2">
                <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white text-sm"><i class="fas fa-bolt"></i></div>
                <span class="font-bold text-lg">ULTRA</span>
            </a>
            <a href="https://whatsapp.com/channel/0029VavHzv259PwTIz1XxJ09" target="_blank" class="text-green-600 text-xs font-bold"><i class="fab fa-whatsapp"></i> Channel</a>
        </header>

        <!-- SEARCH BOX -->
        <div class="bg-white p-2 rounded-xl shadow-sm border border-gray-100 mb-6">
            <form method="POST" class="flex gap-2" @submit="loading = true">
                <input type="hidden" name="action" value="search">
                <input type="text" name="query" placeholder="Search or paste link..." value="<?php echo htmlspecialchars($query); ?>" class="flex-grow px-4 py-2 text-sm outline-none font-medium" required>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2">
                    <span x-show="!loading"><i class="fas fa-search"></i></span>
                    <i x-show="loading" class="fas fa-spinner fa-spin"></i>
                </button>
            </form>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 text-[11px] p-2 rounded-lg mb-4 text-center font-bold uppercase tracking-wider"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- DETAILS PAGE -->
        <?php if ($show_details && $video_details): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden animate-fade-in max-w-md mx-auto">
                <div class="p-4">
                    <a href="index.php" class="text-blue-600 text-xs font-bold mb-4 inline-block"><i class="fas fa-arrow-left mr-1"></i> Back</a>
                    <div class="flex gap-4 mb-4">
                        <img src="<?php echo htmlspecialchars($video_details['thumbnail']); ?>" class="w-24 h-24 object-cover rounded-lg shadow-sm">
                        <div class="flex-grow">
                            <h3 class="font-bold text-sm line-clamp-2 leading-tight mb-1"><?php echo htmlspecialchars($video_details['title']); ?></h3>
                            <p class="text-[10px] text-gray-400 font-bold"><?php echo htmlspecialchars($video_details['duration']); ?> • <?php echo format_views($video_details['views']); ?> views</p>
                        </div>
                    </div>

                    <?php if ($download_link): ?>
                        <a href="<?php echo htmlspecialchars($download_link); ?>" target="_blank" download class="block w-full bg-green-600 text-white text-center font-bold py-3 rounded-lg text-sm shadow-lg shadow-green-100"><i class="fas fa-download mr-2"></i> DOWNLOAD NOW</a>
                    <?php else: ?>
                        <form method="POST" @submit="loading = true">
                            <input type="hidden" name="action" value="download">
                            <?php foreach($video_details as $k => $v): ?>
                                <input type="hidden" name="video_<?php echo $k; ?>" value="<?php echo htmlspecialchars($v); ?>">
                            <?php endforeach; ?>
                            <button type="submit" class="w-full bg-blue-600 text-white font-bold py-3 rounded-lg text-sm flex items-center justify-center gap-2">
                                <span x-show="!loading">GENERATE LINK</span>
                                <span x-show="loading" class="flex items-center gap-2"><i class="fas fa-spinner fa-spin"></i> WORKING...</span>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

        <!-- SEARCH RESULTS -->
        <?php elseif (!empty($search_results)): ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <?php foreach ($search_results as $video): ?>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden compact-card">
                        <div class="aspect-video relative">
                            <img src="<?php echo htmlspecialchars($video['thumbnail']); ?>" class="w-full h-full object-cover">
                            <div class="absolute bottom-1 right-1 bg-black/70 text-white text-[9px] px-1.5 py-0.5 rounded-md font-bold"><?php echo htmlspecialchars($video['duration']); ?></div>
                        </div>
                        <div class="p-2">
                            <h3 class="font-bold text-[11px] line-clamp-1 mb-2"><?php echo htmlspecialchars($video['title']); ?></h3>
                            <form method="POST">
                                <input type="hidden" name="action" value="view_details">
                                <input type="hidden" name="video_id" value="<?php echo htmlspecialchars($video['videoId']); ?>">
                                <input type="hidden" name="video_title" value="<?php echo htmlspecialchars($video['title']); ?>">
                                <input type="hidden" name="video_thumbnail" value="<?php echo htmlspecialchars($video['thumbnail']); ?>">
                                <input type="hidden" name="video_duration" value="<?php echo htmlspecialchars($video['duration']); ?>">
                                <input type="hidden" name="video_views" value="<?php echo htmlspecialchars($video['views']); ?>">
                                <input type="hidden" name="video_author" value="YouTube">
                                <input type="hidden" name="video_uploaded" value="<?php echo htmlspecialchars($video['published']); ?>">
                                <button type="submit" class="w-full bg-gray-50 hover:bg-gray-100 text-gray-900 py-1.5 rounded-md font-bold text-[10px] border border-gray-100 transition-all">GET VIDEO</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <footer class="mt-10 text-center text-[10px] text-gray-300 font-bold uppercase tracking-widest">
            © 2026 ULTRA DOWNLOADER
        </footer>
    </div>

    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
</body>
</html>
